using System;
using UnityEngine;
using System.Collections.Generic;

public class BoardGenerator {
	Board board;
	GameObject gridPre;
	
	public BoardGenerator(Board board, GameObject gridPre) {
		this.board = board;		
		this.gridPre = gridPre;
	}
	
	public void Generate() {
		var minePoses = RandomPositions(board.MinesCnt);
		GenerateGrids(minePoses);
	}
	
	HashSet<Position> RandomPositions(int count) {
		var poses = new HashSet<Position>();
		while(poses.Count < count) {
			Position pos = board.RandomPos();
			
			if(!poses.Contains(pos)) {
				poses.Add(pos);
			}
		}
		return poses;
	}
	
	void GenerateGrids(HashSet<Position> minePoses) {
		foreach(var pos in board) {
			GameObject go = GameObject.Instantiate(gridPre) as GameObject;
			go.transform.parent = board.transform;
			Grid grid = go.GetComponent<Grid>();
			grid.Initialize(pos, minePoses.Contains(pos));
			board[pos] = grid;
		} 
		foreach(var pos in board) { 
			board[pos].UpdateIndicator();
		}
	}
}

