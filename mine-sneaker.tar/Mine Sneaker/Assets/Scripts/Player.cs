using UnityEngine;
using System.Collections;
using System;

public class Player : MonoBehaviour {
	[Serializable]
	public class CustomCursor {
		public Texture2D texture;
		public Vector2 hospot;
		public CursorMode cursorMode;
	}
	
	public CustomCursor normalCursor;
	public CustomCursor pickupCursor;
	
	bool hold = false;	
	
	public bool Hold {
		get { return hold; }
	}
	
	public void Pickup() {
		hold = true;	
	}
	
	public void SetDown() {
		hold = false;	
	}
	
	void Awake() {
		SetCursor(normalCursor);
	}
	
	// Update is called once per frame
	void Update() {
		if(hold)
			SetCursor(pickupCursor); 
		else
			SetCursor(normalCursor);
	}
	
	void SetCursor(Player.CustomCursor c) {
		Cursor.SetCursor(c.texture, c.hospot, c.cursorMode);
	}
}
