using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class Grid : MonoBehaviour {
	Position pos;
	bool covered = true;
	bool hasMine;
	bool marked = false;
	bool tomb = false;
	int indicator = 0;
	
	GridDisplay display;	
	
	public int Indicator {
		get { return indicator; }
		set { indicator = value; }
	}
	
	public Position Pos { get { return pos; } }
	public bool Covered { get { return covered; } } 
	public bool HasMine { get { return hasMine; } }
	public bool Marked { get { return marked; } }
	public bool Tomb { get { return tomb; } }
	
	// can't use constructor because it's created along with Instantiate()
	public void Initialize(Position pos, bool hasMine) {
		this.pos = pos;
		this.hasMine = hasMine;
		
		this.display = new GridDisplay(this, GetComponent<exSprite>());
		this.display.MapPosition();
	}

	public List<Grid> Neighbors() {
		return pos.Neighbors().Select(nPos => Level.Board[nPos]).ToList();
	}	
	
	public bool Press() {
		if(covered) {
			Uncover();
			if(hasMine) { //Boom!
				tomb = true;	
				Level.Board.RemainingMinesCnt--;
				return false;
			} else {
				if(indicator == 0) { // Open an opening
					var neighborsWihtoutMine = Neighbors().Where(g => !g.hasMine);
					foreach(var g in neighborsWihtoutMine) {
						g.Press();	
					}	
				}		
			}
		}
		
		return true;
	}
	
	public void Mark() {
		if(covered && hasMine) {
			marked = true;
			Level.Board.RemainingMinesCnt--;
			Level.Board.MarkedGridsCnt++;
		}
	}
	
	public void UpdateIndicator() {
		indicator = Neighbors().Where(g => g.hasMine).Count();
	}

	// Update is called once per frame
	void Update() {
		UpdateIndicator(); 
		display.Update();	
	}
	
	void OnMouseDown() {
		if(Level.LevelStatus != Level.Status.Running)
			return;
		
		var player = Level.Player;
		if(covered && !marked) {
			if(hasMine && !player.Hold) {
				hasMine = false;
				Level.Board.RemainingMinesCnt--;
				player.Pickup();
			} else if(!hasMine && player.Hold) {
				hasMine = true;
				Level.Board.RemainingMinesCnt++;
				player.SetDown();
			}
		}
	}
	
	void Uncover() {
		covered = false;
		Level.Board.UncoveredGridsCnt++;
	} 
}
