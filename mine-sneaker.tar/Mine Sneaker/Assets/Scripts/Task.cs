using System;
using UnityEngine;

public struct Task {
	public static readonly Task None = new Task(default(Position), Action.None);
	
	public enum Action {
		None, Press, Mark, MultiPress, GuessPress
	}
	
	public Position target;
	public Action act;
	
	public Vector2 PxlPos {
		get { return Position.PosToPxl(target); }
	}
	
	public Task(Position target, Action act) {
		this.target = target;	
		this.act = act;
	}

}

