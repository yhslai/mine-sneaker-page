using UnityEngine;
using System.Collections;

public class Dialogue : MonoBehaviour {
	public exBitmapFont failFont;
	public exBitmapFont victoryFont;
	
	// Use this for initialization
	void Start() {
		exSpriteFont headFont = transform.FindChild("Header").GetComponent<exSpriteFont>();
		exSpriteFont bodyFont = transform.FindChild("Body").GetComponent<exSpriteFont>();
		exSpriteFont commentFont = transform.FindChild("Comment").GetComponent<exSpriteFont>();
		float time = Level.RunningTime;
		
		if(Level.LevelStatus == Level.Status.Fail) {
			headFont.fontInfo = failFont;			
			headFont.text = "Defeat";
			
			bodyFont.text = string.Format("{0:F1}", time);
			
			if(time > Game.failRecords[Game.Level] || Game.failRecords[Game.Level] == 0.0f) {
				commentFont.text = "NEW!";	
				Game.failRecords[Game.Level] = time;	
				Game.SaveRecords();
			} else {
				commentFont.text = "";
			}
		} else if(Level.LevelStatus == Level.Status.Victory) {
			headFont.fontInfo = victoryFont;
			headFont.text = "Victory";
			
			bodyFont.text = string.Format("{0:F1}", time);
			
			if(time < Game.victoryRecords[Game.Level] || Game.victoryRecords[Game.Level] == 0.0f) {
				commentFont.text = "NEW!";	
				Game.victoryRecords[Game.Level] = time;	
				Game.SaveRecords();
			} else {
				commentFont.text = "";
			}
		}
		
		
	}
}
