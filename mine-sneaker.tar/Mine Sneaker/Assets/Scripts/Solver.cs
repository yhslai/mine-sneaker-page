using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class Solver : MonoBehaviour, IPxlPositionable {
	public enum State {
		Cooldown, Guessing, Executing
	}
	
	public enum Type {
		Dumb, Careful, Fast
	}
		
	public float speed;
	public int maxTask;
	public float coolDownTime;
	public float guessDelay;
	public float warmUpDelay;
	public Type type;
	
	Vector2 pxlPos;
	Queue<Task> tasks = new Queue<Task>();
	Task currentTask = Task.None;
	float coolDown;
	float warmUp;
	State currentState = State.Cooldown;
	
	SolverDisplay display;
	PxlPositionMapper positionMapper;

	public Vector2 PxlPos {
		get { return pxlPos; }
		set { pxlPos = value; }
	}
	public State CurrentState { get { return currentState; } }
	
	public Position Pos {
		get { return Position.PxlToPos(pxlPos); }
	}
	
	public void Initialize() {
		positionMapper = new PxlPositionMapper(this, transform);
		pxlPos = Level.Board.RandomPxlPos();
		GetComponent<exLayer>().parent = GameObject.Find("Sprite Layer").GetComponent<exLayer>();
		
		display = new SolverDisplay(this, GetComponent<exSprite>(), GetComponent<exSpriteAnimation>());
	}
	
	public void AddTask(Task task) {
		List<Task> ts = tasks.ToList();
		ts.Add(task);
		var query = ts.OrderBy(t => Vector2.Distance(t.PxlPos, pxlPos)).Take(maxTask);
		tasks.Clear();
		foreach(var t in query)
			tasks.Enqueue(t);

	}
	
	public void Die() {
		Level.SolverManager.RemoveSolver(this);
		Destroy(gameObject);
	}
	
	// Update is called once per frame
	void Update() {
		if(Level.LevelStatus != Level.Status.Running)
			return;
		
		if(!currentTask.Equals(Task.None)) {
			executeTask(currentTask);
		} else {
			if(coolDown < 0) {
				if(tasks.Count > 0) {
					currentTask = tasks.Dequeue();
				} else {
					Level.SolverManager.GenerateTasks();
					if(tasks.Count == 0) {
						currentState = State.Guessing;
						coolDown = guessDelay; 
						AddTask(Level.SolverManager.GetGuessTask());
					}
				}
			} else {
				coolDown -= Time.deltaTime;
			}
		}
		
		display.Update();
		positionMapper.MapPosition();	
	}
	
	void executeTask(Task t) {
		var targetPxlPos = Position.PosToPxl(t.target);
		float distance = Vector2.Distance(pxlPos, targetPxlPos);
		
		if((t.act == Task.Action.Press && !Level.Board[t.target].Covered) || 
		   (t.act == Task.Action.Mark && Level.Board[t.target].Marked)) {
			currentTask = Task.None;
			return;
		}
		
		Grid g = Level.Board[t.target];
		if(t.act == Task.Action.MultiPress && g.Neighbors().Where(ng => (ng.Covered && !ng.Marked)).Count() == 0) {
			currentTask = Task.None;
			return;
		}
			
		
		if(type == Type.Careful) {
			if((t.act == Task.Action.Press && Level.Board[t.target].HasMine) ||
			   (t.act == Task.Action.Mark && !Level.Board[t.target].HasMine)) {
			    Debug.Log("Discard: " + t.target);
				FinishTask();
				return;
			}
		}
		
		if(type != Type.Fast && t.act == Task.Action.MultiPress) {
			currentTask = Task.None;
			return;
		}
		
		if(distance < 1e-5) {
			if(warmUp < 0) {
				ExecuteAction(t.act);
				FinishTask();
			} else {
				warmUp -= Time.deltaTime;
			}
		} else {
			pxlPos = Vector2.MoveTowards(pxlPos, targetPxlPos, speed * Time.deltaTime);	
		}
		
		if(t.act == Task.Action.GuessPress)
			currentState = State.Guessing;
		else
			currentState = State.Executing;
	}
	
	void ExecuteAction(Task.Action act) {
		switch(act) {
		case Task.Action.Press:
			Level.Board.Press(this);
			break;
		case Task.Action.Mark:
			Level.Board.Mark(this);
			break;
		case Task.Action.GuessPress:
			Level.Board.Press(this);
			break;
		case Task.Action.MultiPress:
			Level.Board.MultiPress(this);
			break;	
		}
	}
	
	void FinishTask() {
		currentTask = Task.None;	
		coolDown = coolDownTime;
		currentState = State.Cooldown;
		warmUp = warmUpDelay;
	}
}
