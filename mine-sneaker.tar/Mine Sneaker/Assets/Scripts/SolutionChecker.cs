using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class SolutionChecker {
	public Dictionary<Position, bool> Knowns = new Dictionary<Position, bool>();
	public Dictionary<Position, bool> Mines = new Dictionary<Position, bool>();
	
	Board board;
	
	public SolutionChecker(Board board) {
		this.board = board;
		Initialize();
	}
	
	void Initialize() {
		foreach(var pos in board) {
			Knowns[pos] = !board[pos].Covered || board[pos].Marked;
			Mines[pos] = board[pos].HasMine;
		}
	}
	
	public void Check(Position pos, bool mine) {
		if(Knowns[pos])
			return;
		
		Knowns[pos] = true;
		Mines[pos] = mine;
		if(pos.Neighbors().All(p => IndicatorValid(p))) {
			Knowns[pos] = false;
		} else {
			Mines[pos] = !mine;
		}
	}
	
	bool IndicatorValid(Position pos) {
		// unknown indicators are always valid
		if(board[pos].Covered)
			return true;
		
		int indicator = board[pos].Indicator;
		int minMineCnt = pos.Neighbors().Where(p => {
			return Knowns[p] && Mines[p];
		}).Count();
		int maxMineCnt = pos.Neighbors().Where(p => {
			return !Knowns[p] || Mines[p];
		}).Count();
		
		return indicator >= minMineCnt && indicator <= maxMineCnt;
	}
}

