using UnityEngine;
using System.Collections;

public class Level : MonoBehaviour {
	public enum Status {
		Waiting, Running, Victory, Fail
	}
	
	public static Board Board;
	public static SolverManager SolverManager;
	public static Player Player;
	public static Status LevelStatus;
	public static float RunningTime;
	public static GameObject DialoguePre;
	
	public GameObject boardGo; 
	public GameObject solverManagerGo;
	public GameObject playerGo;
	public GameObject dialoguePre;
	
	public static void Victory() {
		if(LevelStatus == Status.Running)
			LevelStatus = Status.Victory;
		GameObject.Instantiate(DialoguePre); 
	}
	
	public static void Fail() {
		if(LevelStatus == Status.Running)
			LevelStatus = Status.Fail;
		GameObject.Instantiate(DialoguePre); 
	}

	// Use this for initialization
	void Awake() {
		LevelStatus = Status.Running;
		Board = boardGo.GetComponent<Board>();	
		SolverManager = solverManagerGo.GetComponent<SolverManager>();
		Player = playerGo.GetComponent<Player>();
		DialoguePre = dialoguePre;
		RunningTime = 0;
	}
	
	void Start() {
		SolverManager.CreateSolver();
	}
	
	void Update() {
		if(LevelStatus == Status.Running) {
			RunningTime += Time.deltaTime;
		}
	}
}
