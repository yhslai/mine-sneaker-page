using UnityEngine;
using System.Collections;

public class Game : MonoBehaviour {
	public int totalLevel;
	
	public static int Level;
	public static int TotalLevel;
	public static int CompletedLevel;
	public static float[] failRecords;
	public static float[] victoryRecords;
	
	public static void SaveRecords() {
		for(int i=0; i<TotalLevel; i++) {
			PlayerPrefs.SetFloat("fail_record_" + i.ToString(), failRecords[i]);
			PlayerPrefs.SetFloat("victory_record_" + i.ToString(), victoryRecords[i]);
		}
	}

	// Use this for initialization
	void Awake () {
		TotalLevel = totalLevel;
		CompletedLevel = -1;
		failRecords = new float[TotalLevel];
		victoryRecords = new float[TotalLevel];
		for(int i=0; i<TotalLevel; i++) {
			failRecords[i] = PlayerPrefs.GetFloat("fail_record_" + i.ToString());
			victoryRecords[i] = PlayerPrefs.GetFloat("victory_record_" + i.ToString());
			if(victoryRecords[i] != 0.0f)
				CompletedLevel = i;
		}
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
