using UnityEngine;
using System.Collections;

public class MineIndicator : MonoBehaviour {
	// Update is called once per frame
	void Update() {
		GetComponent<exSpriteFont>().text = Level.Board.RemainingMinesCnt.ToString();
	}
}
