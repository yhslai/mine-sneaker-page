using System;
using UnityEngine;

public class Coordinate {
	Vector2 coord;
	Transform transform;
	
	public Coordinate(Transform transform) {
		this.transform = transform;
	}	
	
	public Vector2 Coord {
		get { return coord; }
		set {
			coord = value;
			transform.localPosition = new Vector2(coord.x, -coord.y);
		}
	}
	
}

