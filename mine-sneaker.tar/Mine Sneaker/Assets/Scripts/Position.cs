using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public struct Position {
	public int r;
	public int c;
	
	public static Vector2 PosToPxl(Position pos) {
		return new Vector2(pos.c * DisplayConfig.gridSize, pos.r * DisplayConfig.gridSize);
	}
	
	public static Position PxlToPos(Vector2 pxlPos) {
		return new Position((int)(pxlPos.y / DisplayConfig.gridSize),
							(int)(pxlPos.x / DisplayConfig.gridSize));
	}
	
	public Position(int r, int c) {
		this.r = r;
		this.c = c;
	}
	
	public override string ToString() {
		return "Position: (" + r + " , " + c + ")";
	}
	
	public List<Position> Neighbors() {
		var neighbors = new List<Position>(); 
		var board = Level.Board;
		for(int dr=-1; dr<=1; dr++)
			for(int dc=-1; dc<=1; dc++) {
				var newPos = new Position(r + dr, c + dc);
				if((dr != 0 || dc != 0) && board.InRange(newPos)) {
					neighbors.Add(newPos);
				}
			}
		return neighbors;		
	}
}

