using System;

public static class BoardConfig {
	public static int Row = 15;
	public static int Column = 24;
	public static int Mine = 99;	
}

