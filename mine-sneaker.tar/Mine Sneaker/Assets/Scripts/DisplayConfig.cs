using System;

public static class DisplayConfig {
	public static int gridSize = 24;
}

