using UnityEngine;
using System.Collections;

public class GridCursor : MonoBehaviour {
	MeshRenderer renderer;
	Grid grid;
	
	void Start() {
		renderer = GetComponent<MeshRenderer>();
		renderer.enabled = false;
		grid = transform.parent.GetComponent<Grid>();
	}
	void OnMouseOver() {
		renderer.enabled = true;
	}
	void OnMouseExit() {
		renderer.enabled = false;
	}
	void OnMouseDown() {
		grid.MouseDown();
	}
}
