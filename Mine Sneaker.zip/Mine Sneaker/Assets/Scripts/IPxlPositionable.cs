using System;
using UnityEngine;

public interface IPxlPositionable {
	Vector2 PxlPos { get; set; }
}

