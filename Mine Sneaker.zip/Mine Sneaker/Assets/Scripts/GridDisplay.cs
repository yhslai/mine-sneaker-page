using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class GridDisplay : SpriteDisplay {
	Grid grid;
	
	public GridDisplay(Grid grid, exSprite sprite) : base(sprite) {
		this.grid = grid;
	}
	
	public void MapPosition() {
		Position pos = grid.Pos;
		int gridSize = DisplayConfig.gridSize;
		grid.transform.localPosition = new Vector2(pos.c * gridSize, pos.r * gridSize * -1);
	}
	
	public void Update() {
		if(grid.Tomb) {
			ChangeSprite("tomb");
		} else {
			if(grid.Covered) {
				if(grid.HasMine) {
					if(grid.Marked)
						ChangeSprite("covered_mine_marked");
					else
						ChangeSprite("covered_mine");
				} else {
					ChangeSprite("covered");
				}
			} else {
				if(grid.HasMine) {
					ChangeSprite("uncovered_mine");
				} else {
					ChangeSprite("uncovered_" + grid.Indicator.ToString());
				}
			}
		}
	}
	
}
