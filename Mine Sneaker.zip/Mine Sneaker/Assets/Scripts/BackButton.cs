using UnityEngine;
using System.Collections;

public class BackButton : MonoBehaviour {
	void OnMouseDown() {
		Application.LoadLevel("level select");		
	}
}
