using UnityEngine;
using System;

public class SolverDisplay : SpriteDisplay {
	Solver solver;
	exSpriteAnimation spriteAnim;
	
	public SolverDisplay(Solver solver, exSprite sprite, exSpriteAnimation spriteAnim) : base(sprite) {
		this.solver = solver;
		this.spriteAnim = spriteAnim;
	}
	
	public void Update() {
		exSpriteAnimState curAnimState = spriteAnim.GetCurrentAnimation();
		if(solver.CurrentState == Solver.State.Guessing) {
			if(curAnimState == null ||
			   (curAnimState.name != "guess" && curAnimState.name != "guess_careful" && curAnimState.name != "guess_fast")) {
				if(solver.type == Solver.Type.Dumb)
					spriteAnim.Play("guess");
				if(solver.type == Solver.Type.Careful)
					spriteAnim.Play("guess_careful");
				if(solver.type == Solver.Type.Fast)
					spriteAnim.Play("guess_fast");
			}
		} else {
			spriteAnim.Stop();
			if(solver.type == Solver.Type.Dumb)
				ChangeSprite("normal");
			if(solver.type == Solver.Type.Careful)
				ChangeSprite("normal_careful");
			if(solver.type == Solver.Type.Fast)
				ChangeSprite("normal_fast");
		}
	}
}

