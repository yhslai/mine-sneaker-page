using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

[Serializable]
public class SolverPreArray : IEnumerable<GameObject> {
	public GameObject[] solverPres;
	public GameObject this[int index] {
		get { return solverPres[index]; }
		set { solverPres[index] = value; }
	}
	
	public IEnumerator<GameObject> GetEnumerator() {
		return solverPres.Cast<GameObject>().GetEnumerator();
	}
	IEnumerator IEnumerable.GetEnumerator() {
		return GetEnumerator();
	}
}

public class SolverManager : MonoBehaviour {
	public SolverPreArray[] solverPres;
	
	List<Solver> solvers = new List<Solver>();	

	public void CreateSolver() {
		foreach(var solverPre in solverPres[Game.Level]) {
			GameObject solverGo = Instantiate(solverPre) as GameObject;
			solverGo.transform.parent = Level.Board.transform;	
			Solver solver = solverGo.GetComponent<Solver>();
			solver.Initialize();
			
			solvers.Add(solver);	
		}
	}
	
	public void RemoveSolver(Solver solver) {
		solvers.Remove(solver);
		if(solvers.Count == 0) {
			Level.Victory();
		}
	}
	
	public void GenerateTasks() {
		var tasks = new List<Task>();
		Board board = Level.Board;
		
		if(board.UncoveredGridsCnt == 0 && board.MarkedGridsCnt == 0) {
			for(int i=0; i<solvers.Count; i++) {
				Position pos;
				while(true) {
					pos = board.RandomPos();
					if(board[pos].Indicator == 0 && !board[pos].HasMine) {
						break;	
					}
				}
				tasks.Add(new Task(pos, Task.Action.Press));
			} 
		} else {
			foreach(var pos in board) {
				Grid g = board[pos];
				if(!g.Covered && g.Indicator > 0 &&
				   g.Indicator == g.Neighbors().Where(ng => ng.Marked).Count() &&
				   g.Neighbors().Where(ng => (ng.Covered && !ng.Marked)).Count() > 0)
					tasks.Add(new Task(pos, Task.Action.MultiPress));
			}
			
			var checker = new SolutionChecker(board);
			foreach(var pos in board) {
				checker.Check(pos, false);
				checker.Check(pos, true);
			}
			foreach(var pos in board) {
				if(board[pos].Covered && !board[pos].Marked && checker.Knowns[pos]) {
					tasks.Add(new Task(pos, checker.Mines[pos] ? Task.Action.Mark : Task.Action.Press));
				}
			}
		}
		
		DispatchTasks(tasks);
	}
	
	public Task GetGuessTask() {
		Board board = Level.Board;
		Position pos;
		while(true) {
			pos = board.RandomPos();
			if(board[pos].Covered && !board[pos].Marked) {
				break;	
			}
		}
		return new Task(pos, Task.Action.GuessPress);
	}
	
	void DispatchTasks(List<Task> tasks) {
		for(int i=0; i<tasks.Count; i++)
			solvers[i % solvers.Count].AddTask(tasks[i]);
	}
}
