using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class SpriteDisplay {
	exSprite sprite;
	Dictionary<string, int> spriteIndexer = new Dictionary<string, int>();

	public SpriteDisplay(exSprite sprite) {
		this.sprite = sprite;
		
		var nameIndices = sprite.atlas.elements.Select((ele, index) => new { name = ele.name, index });
		foreach(var item in nameIndices) {
			spriteIndexer[item.name] = item.index;
		}
	}
	
	protected void ChangeSprite(string spName) {
		sprite.SetSprite(sprite.atlas, spriteIndexer[spName]);	
	} 
}

