using UnityEngine;
using System.Collections;

public class LevelButton : MonoBehaviour {
	public string lockSpName;
	public string uncompletedSpName;
	public string completedSpName;
	public int level;

	// Use this for initialization
	void Start() {
		if(level > Game.CompletedLevel + 1)
			ChangeSprite(lockSpName);
	}
	
	void OnMouseDown() {
		if(level <= Game.CompletedLevel + 1) {
			ChangeSprite(completedSpName);
		}
	}
	
	void OnMouseUp() {
		if(level > Game.CompletedLevel)
			ChangeSprite(uncompletedSpName);
	}
	
	void OnMouseUpAsButton() {
		Game.Level = level;
		Application.LoadLevel("main");
	}
	
	
	void ChangeSprite(string spName) {
		var sprite = GetComponent<exSprite>();
		sprite.SetSprite(sprite.atlas, sprite.atlas.GetIndexByName(spName));
	}
}
