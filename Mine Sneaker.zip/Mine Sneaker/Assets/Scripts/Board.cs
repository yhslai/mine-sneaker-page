using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;

public class Board : MonoBehaviour, IEnumerable<Position> {
	public int Row;
	public int Column;
	public int MinesCnt;
	public GameObject gridPre;
	System.Random random = new System.Random();
	
	BoardGenerator boardGenerator;
	
	Grid[,] grids;
	
	public bool InRange(Position pos) {
		return InRange(pos.r, pos.c);
	}
	
	public Vector2 RandomPxlPos() {
		return new Vector2((float)random.NextDouble()*Width, (float)random.NextDouble()*Height);
	}
	
	public Position RandomPos() {
		return new Position(random.Next(0, Row), random.Next(0, Column));
	}
	
	public Grid this[Position pos] {
		get { return this[pos.r, pos.c]; }
		set { this[pos.r, pos.c] = value; }
	} 
	
	public int Width { get; private set; }
	public int Height { get; private set; }
	public int RemainingMinesCnt { get; set; }
	public int UncoveredGridsCnt { get; set; }
	public int MarkedGridsCnt { get; set; }
	public int GridsCnt {
		get { return Row * Column; }	
	}
	
	public IEnumerator<Position> GetEnumerator() {
		for(int r=0; r<Row; r++)
			for(int c=0; c<Column; c++)
				yield return new Position(r, c);
	}
	
	public void Press(Solver solver) {
		Position target = solver.Pos;
		if(!this[target].Press()) { //Boom!!
			solver.Die();
		} else {
			CheckFinished();
		}
	}
	
	public void Mark(Solver solver) {
		Position target = solver.Pos;
		this[target].Mark();
		CheckFinished();
	}
	
	public void MultiPress(Solver solver) {
		Position target = solver.Pos;
		foreach(var np in target.Neighbors()) {
			if(!this[np].HasMine)
				this[np].Press();
		}
		CheckFinished();
	}
	
	bool InRange(int r, int c) {
		return r >= 0 && r < Row && c >= 0 && c < Column;
	}
	
	Grid this[int r, int c] {
		get { return grids[r, c]; }
		set { grids[r, c] = value; }
	}
	
	IEnumerator IEnumerable.GetEnumerator() {
		return GetEnumerator();
	}
	
	void Awake() {
		grids = new Grid[Row, Column];
		Width = Column * DisplayConfig.gridSize;
		Height = Row * DisplayConfig.gridSize;
	}
	
	void Start() {
		RemainingMinesCnt = MinesCnt;
		UncoveredGridsCnt = 0;
		MarkedGridsCnt = 0;
		
		boardGenerator = new BoardGenerator(this, gridPre);	
		boardGenerator.Generate();
	}
	
	void CheckFinished() {
		if(RemainingMinesCnt == 0 || RemainingMinesCnt + UncoveredGridsCnt + MarkedGridsCnt == GridsCnt)
			Level.Fail();
	}
}
