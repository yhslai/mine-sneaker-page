using UnityEngine;
using System.Collections;

public class FaceIconDisplay : MonoBehaviour {
	// Update is called once per frame
	void Update() {
		string spName = "";
		switch(Level.LevelStatus) {
		case Level.Status.Running:
			spName = "face_normal";
			break;
		case Level.Status.Fail:
			spName = "face_fail";
			break;
		case Level.Status.Victory:
			spName = "face_victory";
			break;
		}
		var sprite = GetComponent<exSprite>();
		sprite.SetSprite(sprite.atlas, sprite.atlas.GetIndexByName(spName));
	}
}
