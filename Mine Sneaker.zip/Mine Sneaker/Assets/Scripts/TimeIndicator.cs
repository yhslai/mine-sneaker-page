using UnityEngine;
using System.Collections;

public class TimeIndicator : MonoBehaviour {
	// Update is called once per frame
	void Update() {
		GetComponent<exSpriteFont>().text = string.Format("{0:F1}", Level.RunningTime);	
	}
}
