using System;
using UnityEngine;

public class PxlPositionMapper {
	IPxlPositionable entity;
	Transform mappingTransform;
	
	public PxlPositionMapper(IPxlPositionable entity, Transform transform) {
		this.entity = entity;
		this.mappingTransform = transform;
	}
	
	public void MapPosition() {
		// Don't change z because it's exLayer's work
		Vector3 newPos = mappingTransform.localPosition;
		newPos.x = entity.PxlPos.x;
		newPos.y = -entity.PxlPos.y;
		mappingTransform.localPosition = newPos;
	}
	
}

