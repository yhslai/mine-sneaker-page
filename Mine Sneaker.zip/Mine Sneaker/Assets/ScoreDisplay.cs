using UnityEngine;
using System.Collections;

public class ScoreDisplay : MonoBehaviour {
	public int level;
	public exSpriteFont vRecord;
	public exSpriteFont fRecord;
	
	void Update() {
		if(Game.victoryRecords[level] == 0.0f)
			vRecord.text = "NONE";
		else
			vRecord.text = string.Format("{0:F1}", Game.victoryRecords[level]);
		if(Game.failRecords[level] == 0.0f)
			fRecord.text = "NONE";
		else
			fRecord.text = string.Format("{0:F1}", Game.failRecords[level]);
	}
}
